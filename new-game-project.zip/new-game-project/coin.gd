extends Area2D

@export var value: int = 1

func _ready() -> void:
	# Connect the body_entered signal safely via code or the Node dock
	body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node2D) -> void:
	# Check if the player entered the area
	if body.is_in_group("player"):
		# Optional: Call a function on the player to add score/coins
		if body.has_method("add_coin"):
			body.add_coin(value)
		
		# Remove the coin from the scene
		queue_free()
